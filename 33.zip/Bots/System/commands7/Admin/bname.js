const Discord = require('discord.js');

module.exports = {
  name: "setname",
  aliases: ["تغيير-الاسم"],
  description: "تغيير اسم البوت.",
  usage: ["!setname <اسم جديد>"],
  botPermission: ["MANAGE_GUILD"],
  authorPermissions: ["MANAGE_GUILD"],
  cooldowns: [],
  ownerOnly: true,
  run: async (client, message, args) => {
    if (!args[0]) {
      return message.reply({
        content: "❗ **يرجى إدخال اسم جديد للبوت**",
      });
    }

    const newName = args.join(" ");
    
    try {
      await client.user.setUsername(newName);
      return message.reply({
        content: `✔ **تم تغيير اسم البوت إلى \`${newName}\` بنجاح**`,
      });
    } catch (error) {
      console.error(`خطأ في تغيير اسم البوت: ${error.message}`);
      return message.reply({
        content: `❗ **حدث خطأ أثناء تغيير اسم البوت، يرجى المحاولة لاحقًا**`,
      });
    }
  }
};
