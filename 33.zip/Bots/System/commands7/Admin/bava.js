const Discord = require('discord.js');

module.exports = {
  name: "setavatar",
  aliases: ["تغيير-الصورة"],
  description: "تغيير صورة البوت.",
  usage: ["!setavatar <رابط الصورة>"],
  botPermission: ["MANAGE_GUILD"],
  authorPermissions: ["MANAGE_GUILD"],
  cooldowns: [],
  ownerOnly: true,
  run: async (client, message, args) => {
    const avatarUrl = args[0];
    
    if (!avatarUrl) {
      return message.reply({
        content: "❗ **يرجى إدخال رابط صورة جديد**",
      });
    }

    try {
      await client.user.setAvatar(avatarUrl);
      return message.reply({
        content: `✔ **تم تغيير صورة البوت بنجاح**`,
      });
    } catch (error) {
      console.error(`خطأ في تغيير صورة البوت: ${error.message}`);
      return message.reply({
        content: `❗ **حدث خطأ أثناء تغيير صورة البوت، يرجى المحاولة لاحقًا**`,
      });
    }
  }
};
