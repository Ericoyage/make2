const Discord = require('discord.js');

module.exports = {
  name: "antilink",
  aliases: ["منع_رابط", "رابط"],
  description: "منع الأعضاء بدون صلاحيات من إرسال الروابط وتكميمهم إذا حاولوا.",
  botPermission: ["MANAGE_MESSAGES", "MUTE_MEMBERS"],
  authorPermission: ["MANAGE_MESSAGES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    const noPermissionRole = message.guild.roles.cache.find(role => role.name === 'No Links');
    const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');

    // التحقق إذا حاول عضو بدون صلاحيات إرسال رابط
    client.on('messageCreate', async (msg) => {
      if (msg.author.bot) return;

      if (!msg.member.permissions.has('MANAGE_MESSAGES')) {
        const urlPattern = /(https?:\/\/[^\s]+)/g;
        if (urlPattern.test(msg.content)) {
          // إضافة دور "Muted" وحذف الرسالة
          if (!muteRole) return msg.reply('لم يتم العثور على دور رول الميوت!');

          await msg.member.roles.add(muteRole);
          msg.delete().catch(err => console.log(err));

          const embed = new Discord.MessageEmbed()
            .setColor('#ff0000')
            .setDescription(`❌ **muted**`);

          msg.channel.send({ embeds: [embed] });
        }
      }
    });

    message.reply({ content: 'تم تفعيل منع الروابط.' });
  }
};
