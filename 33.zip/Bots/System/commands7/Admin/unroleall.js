const Discord = require('discord.js');

module.exports = {
  name: "roleremoveall",
  aliases: ["إزالة_دور_من_الكل", ""],
  description: "Remove a role from all members in the server",
  usage: ["!roleremoveall <role>"],
  botPermission: ["MANAGE_ROLES"],
  authorPermission: ["MANAGE_ROLES"],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args, config) => {
    if (!args[0]) return message.reply({ content: `❌ **يرجى تحديد الرول الذي تريد إزالته من الجميع!**` });

    let role = message.mentions.roles.first() || message.guild.roles.cache.find(r =>
      r.name.toLocaleLowerCase().includes(args[0].toLowerCase())) || message.guild.roles.cache.get(args[0]);

    if (!role) return message.reply({ content: `❌ **تعذر العثور على هذا الرول!**` });
    if (message.guild.me.roles.highest.position <= role.position)
      return message.reply({ content: `❌ **لا أستطيع إزالة هذا الرول لأنه أعلى/مساوٍ لدوري.**` });

    let members = message.guild.members.cache.filter(member => member.roles.cache.has(role.id));

    if (members.size === 0) {
      return message.reply({ content: `⚠ **لا أحد من الأعضاء يمتلك هذا الرول بالفعل!**` });
    }

    members.forEach(member => {
      member.roles.remove(role.id).catch(err => console.log(`Failed to remove role from ${member.user.tag}: ${err}`));
    });

    return message.reply({ content: `✔ **تمت إزالة دور ${role.name} من ${members.size} عضو بنجاح!**` });
  }
};
