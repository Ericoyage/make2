const Discord = require('discord.js');
const { Database } = require("st.db");
const brodcastdb = new Database("/Json-db/Bots/BrodcastDB.json");
const prefixdb = new Database("/Json-db/Others/PrefixDB.json");

module.exports = {
  name: "bc",
  aliases: [""],
  description: "",
  usage: [""],
  botPermission: [""],
  authorPermission: [],
  cooldowns: [],
  ownerOnly: true, // Ensures this is an owner-only command
  run: async (client, message, args) => {
    try {
      // Check if the message author is the owner
      const ownerId = ["520774569855025152","764205712536371232"]; // Replace with your Discord user ID
      if (message.author.id !== ownerId) {
        return message.reply("❌ هذا الأمر مخصص فقط لصاحب البوت.");
      }

      const prefix = await prefixdb.get(`Prefix_${client.user.id}_brodcast`);
      const broadcastMessage = args.join(" ");
      if (!broadcastMessage) return message.reply(`❗ الاستخدام: ${prefix}bc [الرسالة]`);

      const guild = message.guild;
      const guildMembers = await guild.members.fetch();

      let successCount = 0;
      let failureCount = 0;
      const startTime = Date.now();

      const statusEmbed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle('حالة البرودكاست')
        .setDescription('جاري إرسال البرودكاست...')
        .setThumbnail(client.user.displayAvatarURL()) // Display bot's avatar
        .addFields(
          { name: "تم الإرسال إلى ✔️", value: `0 عضو`, inline: false },
          { name: "لم يتم الإرسال إلى ❌", value: `0 عضو`, inline: false },
          { name: "إجمالي الأعضاء", value: `0 عضو`, inline: false },
          { name: "الوقت المنقضي", value: `جارٍ الحساب...`, inline: false },
          { name: "الوقت المتوقع المتبقي", value: `جارٍ الحساب...`, inline: false }
        );

      const statusMessage = await message.channel.send({ embeds: [statusEmbed] });

      for (const member of guildMembers.values()) {
        try {
          if (member.user.bot) continue;
          await member.send(broadcastMessage);
          successCount++;
        } catch {
          failureCount++;
        }

        // Update embed with current status
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2); // in seconds
        const estimatedRemainingTime = ((elapsedTime / (successCount + failureCount)) * (guildMembers.size - (successCount + failureCount))).toFixed(2);

        const updatedEmbed = new Discord.MessageEmbed()
          .setColor('GREEN')
          .setTitle('حالة البرودكاست')
          .setDescription('جاري إرسال البرودكاست...')
          .setThumbnail(client.user.displayAvatarURL()) // Display bot's avatar
          .addFields(
            { name: "تم الإرسال إلى ✔️", value: `${successCount} عضو`, inline: false },
            { name: "لم يتم الإرسال إلى ❌", value: `${failureCount} عضو`, inline: false },
            { name: "إجمالي الأعضاء", value: `${successCount + failureCount} عضو`, inline: false },
            { name: "الوقت المنقضي", value: `${elapsedTime} ثانية`, inline: false },
            { name: "الوقت المتوقع المتبقي", value: `${estimatedRemainingTime} ثانية`, inline: false }
          );

        await statusMessage.edit({ embeds: [updatedEmbed] });
      }

      // Final embed update after completion
      const totalTime = ((Date.now() - startTime) / 1000).toFixed(2); // in seconds
      const finalEmbed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle('حالة البرودكاست')
        .setDescription('تم الانتهاء من إرسال البرودكاست!')
        .setThumbnail(client.user.displayAvatarURL()) // Display bot's avatar
        .addFields(
          { name: "تم الإرسال إلى ✔️", value: `${successCount} عضو`, inline: false },
          { name: "لم يتم الإرسال إلى ❌", value: `${failureCount} عضو`, inline: false },
          { name: "إجمالي الأعضاء", value: `${successCount + failureCount} عضو`, inline: false },
          { name: "إجمالي الوقت المستغرق", value: `${totalTime} ثانية`, inline: false }
        );

      await statusMessage.edit({ embeds: [finalEmbed] });
    } catch (error) {
      console.log(error);
      return message.reply("❌ حدث خطأ أثناء تنفيذ البرودكاست.");
    }
  }
};
