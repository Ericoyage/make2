const Discord = require('discord.js');

module.exports = {
  name: "help",
  aliases: ["مساعدة", "h"],
  description: "عرض قائمة الأوامر المتاحة.",
  usage: ["help"],
  botPermission: [],
  cooldowns: [],
  ownerOnly: false,
  run: async (client, message, args) => {
    const helpEmbed = new Discord.MessageEmbed()
      .setColor(message.guild.me.displayHexColor || "#00FF00")
      .setTitle(`📜 **أوامر بوت البرودكاست**`)
      .setDescription("هنا تجد قائمة بالأوامر المتاحة:")
      .addFields(
        { name: `🔹 **bc [الرسالة]:**`, value: `إرسال رسالة برودكاست لجميع أعضاء السيرفر.`, inline: false },
        { name: `🔹 **rbc [الرسالة]:**`, value: `إرسال رسالة برودكاست إلى role محدد.`, inline: false },
        { name: `🔹 **brodcast-status :**`, value: `تغيير حالة البوت الحالية.`, inline: false },
        { name: `🔹 **set prefix :**`, value: `تغيير prefix الخاصة بالأوامر.`, inline: false },
        { name: `🔹 **setname :**`, value: `تغيير اسم البوت.`, inline: false },
        { name: `🔹 **setavatar :**`, value: `تغيير صورة البوت إلى الصورة المرفقة.`, inline: false },
        { name: `🔹 **addowner :**`, value: `إضافة شخص إلى قائمة المالكين للبوت.`, inline: false }
      )
      .setFooter("استخدم الأوامر بعناية. جميع الأوامر تحتاج إلى الصلاحيات المناسبة.");

    message.reply({ embeds: [helpEmbed], allowedMentions: { repliedUser: false } });
  }
};
