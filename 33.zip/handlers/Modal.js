const fs = require('fs');
const chalk = require('chalk');
const ascii = require('ascii-table');

let table = new ascii('commands');
table.setHeading('Command', 'Commands Status💹');

module.exports = (client) => {
    // Read all items in the 'Modals' directory
    fs.readdirSync('./Modals').forEach((item) => {
        const itemPath = `./Modals/${item}`;
        
        // Check if the item is a directory
        if (fs.statSync(itemPath).isDirectory()) {
            // Read the command files within the folder
            const commandFiles = fs.readdirSync(itemPath).filter(file => file.endsWith('.js'));
            for (const file of commandFiles) {
                let Modals = require(`../Modals/${item}/${file}`);
                if (Modals.name) {
                    client.modlas.set(Modals.name, Modals);
                    table.addRow(file, '✔');
                } else {
                    table.addRow(file, '❌');
                    continue;
                }
            }
        }
    });

    console.log(table.toString());
};
